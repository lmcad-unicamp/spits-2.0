import setuptools

setuptools.setup(
    name="libspits",
    version="0.0.1",

    description="libspits package",
    packages=setuptools.find_packages(),

    python_requires='>=3.4',
)
