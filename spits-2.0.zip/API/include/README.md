# dev

This directory contains C and C++ headers to support the development of SPITS applications.
For examples on how to use these headers check out the "../../examples" directory.


