#ifndef __TEST_BUFFER_HPP__
#define __TEST_BUFFER_HPP__

void test_integer_buffer(void);

void test_bytes_buffer(void);

#endif /* __TEST_BUFFER_HPP__ */
