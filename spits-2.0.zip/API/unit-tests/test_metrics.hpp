#ifndef __TEST_METRICS_HPP__
#define __TEST_METRICS_HPP__

void test_metric_buffer_interface(void);

#endif /* __TEST_METRICS_HPP__ */
