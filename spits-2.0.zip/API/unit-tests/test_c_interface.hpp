#ifndef __TEST_C_INTERFACE_HPP__
#define __TEST_C_INTERFACE_HPP__

void test_c_interface(void);

#endif /* __TEST_C_INTERFACE_HPP__ */
