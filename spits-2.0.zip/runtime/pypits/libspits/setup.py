from setuptools import setup
setup(name='libspits',
version='0.1',
description='Testing installation of Package',
url='#',
author='malhar',
author_email='mlathkar@gmail.com',
license='MIT',
packages=['mypackage'],
zip_safe=False)
